package com.sda.wielowatkowosc;

public class Jas implements Runnable {
    @Override
    public void run() {
        try {
            System.out.println("Jas szykuje sniadanie...");
            Thread.sleep(5000);
            System.out.println("Jas zrobil sniadanie...");

            System.out.println("Jas idzie pod prysznic...");
            Thread.sleep(3000);
            System.out.println("Jas wrocil spod prysznica...");

            System.out.println("Jas ubiera sie...");
            Thread.sleep(1000);
            System.out.println("Jas ubral sie...");

            System.out.println("Jas idzie na zakupy...");
            Thread.sleep(15000);
            System.out.println("Jas wrocil z zakupow...");

            System.out.println("Jas gra na konsoli...");
            Thread.sleep(5000);
            System.out.println("Jas skonczyl grac na konsoli...");

//            System.out.println("Jas: ide spać przy drzwiach");
//            synchronized (Main.DRZWI) {
//                Main.DRZWI.wait();
//            }
//            System.out.println("Jas: ide na impreze!");

        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
