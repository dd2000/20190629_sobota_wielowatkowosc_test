package com.sda.wielowatkowosc;

public class Main {

    //public static final Object DRZWI = new Object();

    public static void main(String[] args) throws InterruptedException {
        Thread watekJas = new Thread(new Jas());
        Thread watekMalgosia = new Thread(new Malgosia());

        watekJas.start();
        watekMalgosia.start();

        watekJas.join();
        watekMalgosia.join();

        System.out.println("Koniec dnia!");
    }
}