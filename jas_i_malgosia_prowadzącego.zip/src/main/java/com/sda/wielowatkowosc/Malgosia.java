package com.sda.wielowatkowosc;

public class Malgosia implements Runnable {
    @Override
    public void run() {
        try {
            System.out.println("Malgosia idzie biegac...");
            Thread.sleep(6000);
            System.out.println("Malgosia wrocila z biegania...");

            System.out.println("Malgosia idzie pod prysznic...");
            Thread.sleep(2000);
            System.out.println("Malgosia wrocila spod prysznica...");

            System.out.println("Malgosia je sniadanie...");
            Thread.sleep(1000);
            System.out.println("Malgosia zjadla sniadanie...");

            System.out.println("Malgosia ubiera sie...");
            Thread.sleep(1000);
            System.out.println("Malgosia ubrala sie...");

            System.out.println("Malgosia idzie na spotkanie z kolezanka...");
            Thread.sleep(5000);
            System.out.println("Malgosia wrocila z ploteczek...");

//            System.out.println("Malgosia: budze tego kto śpi przy drzwiach");
//            synchronized (Main.DRZWI) {
//                Main.DRZWI.notify();
//            }
//            System.out.println("Malgosia: ide na impreze!");

        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
